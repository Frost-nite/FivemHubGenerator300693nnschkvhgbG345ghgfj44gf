<!DOCTYPE html>
<html lang="en">
<head>
<title>Leak.sx | Accounts leecher</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
<meta name="description" content="Leak.sx - The best account leecher website you always wanted.">
<link rel="icon" type="image/x-icon" href="/inc/theme/assets/img/favicon.ico" />
<link href="https://fonts.googleapis.com/css?family=Quicksand:400,500,600,700&amp;display=swap" rel="stylesheet">
<script data-cfasync="false" type="text/javascript" src="//glassmilheart.com/aas/r45d/vki/1826384/tghr.js"></script>
</head>
<style>
#float_chat {
    position:fixed;
    right:-115px;
    bottom:5px;
    margin:0;
    width:300px;
        z-index: 10;           
}

#float_chat img {
width:60%;
}
</style>
<div id="float_chat"><a href="https://t.me/leak_sx"><img src="/inc/telegram.png" /></a></div>
<link href="/inc/theme/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="/inc/theme/assets/css/custom.css" rel="stylesheet" type="text/css" />
<link href="/inc/theme/assets/css/plugins.css" rel="stylesheet" type="text/css" />
<link href="/inc/theme/assets/css/apps/notes.css" rel="stylesheet" type="text/css" />
<body class="alt-menu sidebar-noneoverflow">

<div class="header-container d-lg-none">
<center>
<img class="logoleaksx" src="/inc/logo.png" alt="LEAK.SX" width="200px">
</center>
</div>


<div class="header-container d-none d-lg-block">
<center>
<img class="logoleaksx" src="/inc/logo.png" alt="LEAK.SX" width="400px">
</center>
</div>

<div class="main-container" id="container">
<div class="overlay"></div>
<div class="search-overlay"></div>

<div class="topbar-nav header navbar" role="banner">
<nav id="topbar">
<ul class="list-unstyled menu-categories" id="topAccordion">
<li class="menu single-menu ">
<a href="/" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle autodroprown">
<div class="">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-home"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
<span>HOME</span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
</a>
</li>
<li class="menu single-menu active">
<a href="/dispenser.php" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle">
<div class="">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
<span>DISPENSER</span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
</a>
</li>
<li class="menu single-menu ">
<a href="https://onlynudes.net/" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle">
<div class="">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-users"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
<span>ADULT LEAKS</span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
</a>
</li>
<li class="menu single-menu ">
<a href="/combolist.php" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle">
<div class="">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-zap"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon></svg>
<span>COMBOLISTS</span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
</a>
</li>
<li class="menu single-menu ">
<a href="/support.php" data-toggle="collapse" aria-expanded="true" class="dropdown-toggle">
<div class="">
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-inbox"><polyline points="22 12 16 12 14 15 10 15 8 12 2 12"></polyline><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"></path></svg>
<span>SUPPORT</span>
</div>
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
</a>
</li>
</ul>
</nav>
</div>


<div id="content" class="main-content">
<div class="layout-px-spacing">
<div style="padding-top:30px; padding-left:15px; padding-right:15px;" class="d-lg-none">
<div class="accordion">
<label for="tm" class="accordionitem">
<center><h5><font style="text-shadow: 1px 1px 4px #25d5e4;" color="#25d5e4">[</font> Navigation <font style="text-shadow: 1px 1px 4px #25d5e4;" color="#25d5e4">]</font></h5></center></label>
<input type="checkbox" id="tm" />
<p class="hiddentext">
<a href="/"><button type="button" class="xdd  btn btn-lg btn-block ">HOME</button></a>
<a href="/dispenser.php"><button type="button" class="xdd  btn btn-lg btn-block xdd-active">DISPENSER</button></a>
<a href="https://onlynudes.net/"><button type="button" class="xdd  btn btn-lg btn-block xdd-active">ADULT LEAKS</button></a>
<a href="/combolist.php"><button type="button" class="xdd  btn btn-lg btn-block ">COMBOLISTS</button></a>
<a href="/support.php"><button type="button" class="xdd  btn btn-lg btn-block ">SUPPORT</button></a>
<a href="/login.php"><button type="button" class="xdd  btn btn-lg btn-block ">LOGIN</button></a></p>
</div>
</div>

<div class="row app-notes layout-top-spacing" id="cancel-row">
<div class="col-lg-12">
<div class="app-container">
<div class="app-note-container">
<div class="app-note-overlay"></div>
<div class="tab-title">

<br><br>
<h6 style="padding-left:20px;">Available leaks</h6>
<div class="row">
<div class="col-md-12 col-sm-12 col-12">
<ul class="nav nav-pills d-block group-list" id="pills-tab" role="tablist">
<h3 style="color:#25d5e4; padding-left:20px; padding-top:5px; text-shadow: 1px 1px 4px #25d5e4;">1419</h3>
</ul>
</div>
</div>
<h6 style="padding-left:20px;">Available combolists</h6>
<div class="row">
<div class="col-md-12 col-sm-12 col-12">
<ul class="nav nav-pills d-block group-list" id="pills-tab" role="tablist">
<h3 style="color:#25d5e4; padding-left:20px; padding-top:5px; text-shadow: 1px 1px 4px #25d5e4;">100</h3>
</ul>
</div>
</div>

<style>
.statsbar {
        background: #191e3a !important;
        border: 1px solid #191e3a;
        margin-bottom: 10px;
        padding-top: 2px;
        padding-bottom: 2px;
        width: 80%;
}
</style>

<div class="sidetop d-none d-lg-block">
</div>

</div>
<div id="ct" class="note-container note-grid">

<div class="ads">
<div class="row">
<div class="col-sm adsimg">
<a href="https://overbooter.ws/?leaksx"><img src="../a_images/overbooter.gif" width="100%" height="55px"></a></div>
<div class="col-sm adsimg">
<a href="https://weleakinfo.to/?leaksx"><img src="../a_images/wli.gif" width="100%" height="55px"></a></div>
<div class="col-sm adsimg">
<a href="https://ipstress.in/?leaksx"><img src="../a_images/ipstresserin.gif" width="100%" height="55px"></a></div>
</div>
</div>
<br>


<div style="display: inline-flex; flex-wrap: wrap;">
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<img src="/a_images/streaming.jpg" style="height:145px" class="card-img-top" alt="widget-card-2">
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">Streaming accounts</h5>
<p class="card-text">Disney+, Netflix and more streaming accounts!</p>
<center><a href="/dispenser_streaming.php" class="btn btn-primary">Explore</a></center>
</div>
</div>
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<img src="/a_images/vpn.jpg" style="height:145px" class="card-img-top" alt="widget-card-2">
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">VPN accounts</h5>
<p class="card-text">NordVPN, VyprVPN, CyberGhost, Mullvad and more VPNs accounts!</p>
<center><a href="/dispenser_vpn.php" class="btn btn-primary">Explore</a></center>
</div>
</div>
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<img src="/a_images/game.jpg" style="height:145px" class="card-img-top" alt="widget-card-2">
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">Gaming accounts</h5>
<p class="card-text">Minecraft, Fortnite, Xbox, Steam and more gaming related accounts!</p>
<center><a href="/dispenser_gaming.php" class="btn btn-primary">Explore</a></center>
</div>
</div>
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<img src="/a_images/music.jpg" style="height:145px" class="card-img-top" alt="widget-card-2">
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">Music accounts</h5>
<p class="card-text">Spotify, Deezer, Pandora, Tidal and more music related accounts!</p>
<center><a href="/dispenser_music.php" class="btn btn-primary">Explore</a></center>
</div>
</div>
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<a href="https://onlynudes.net/"><img src="/a_images/adult.jpg" style="height:145px" class="card-img-top" alt="widget-card-2"></a>
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">Adult leaks</h5>
<p class="card-text">Are you 18+? Access our exclusive Onlyfans and more adult leaks.</p>
<center><a href="https://onlynudes.net/" class="btn btn-primary">Explore</a></center>
</div>
</div>
<div class="card component-card_2" style="width:220px;margin-right: 10px;height: 350px;">
<img src="/a_images/internet.jpg" style="height:145px" class="card-img-top" alt="widget-card-2">
<div class="card-body">
<h5 class="card-title" style="font-size: 1.2rem;">Other accounts</h5>
<p class="card-text">It's not over! Check out all our other leaked free accounts here!</p>
<center><a href="/dispenser_other.php" class="btn btn-primary">Explore</a></center>
</div>
</div>

<div class="container">
<div class="row">
<div class="col-md-4"><center><script data-cfasync="false" type="text/javascript" src="//resalag.com/lv/esnk/1826413/code.js" async id="__clb-1826413"></script></center></div>
<div class="col-md-4"></div>
<div class="col-md-4"><center><script data-cfasync="false" type="text/javascript" src="//resalag.com/lv/esnk/1826414/code.js" async id="__clb-1826414"></script></center></div>
</div>
</div>
</div>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="footertxt" style="padding-top:20px;">
Using any resource of this website you accept our <a href="https://cyber-hub.pw/tos.php">TOS</a> | Copyright © 2014-2021 Megacore, All rights reserved.
</div>
</div>
</div>
<div id="conveythis-wrapper-main"><a href="https://www.conveythis.com" class="conveythis-no-translate notranslate" title="ConveyThis">ConveyThis</a></div>
<script src="//s2.conveythis.com/javascriptClassic/1/conveythis.js"></script>
<script src="//s2.conveythis.com/javascriptClassic/1/translate.js"></script>
<script type="text/javascript">
document.addEventListener("DOMContentLoaded", function(e) {
conveythis.init({source_language_id: 703, languages: [{"id":"703","active":true},{"id":"719","active":false},{"id":"727","active":false},{"id":"730","active":false},{"id":"741","active":false},{"id":"707","active":false},{"id":"768","active":false},{"id":"771","active":false},{"id":"787","active":false},{"id":"777","active":false}]})
});
</script>
</body>
</html>
